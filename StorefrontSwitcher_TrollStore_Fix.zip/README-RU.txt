ИНСТРУКЦИЯ

В архиве:
- StorefrontSwitcher/TrollStore.entitlements — минимальный no-sandbox entitlement.
- .github/workflows/build-ipa.yml — сборка IPA, применение entitlement через ldid.
- apply_patch.py — добавляет видимую метку Build 2 и диагностический вывод, обновляет версию до 1.1 (build 2).

Применение:
1. Распакуй архив в корень клона репозитория keios.
2. Запусти: python3 apply_patch.py
3. Скопируй StorefrontSwitcher/TrollStore.entitlements в соответствующую папку проекта.
4. Скопируй .github/workflows/build-ipa.yml в репозиторий, сохранив путь.
5. Отправь изменения в GitHub и запусти Actions → Build TrollStore IPA.
6. Установи артефакт StorefrontSwitcher-TrollStore.ipa через TrollStore.

После установки внизу экрана должна быть надпись:
Build 2 • TrollStore entitlement test

Если её нет, открыта старая сборка.

Это тестовая сборка, не гарантия совместимости со всеми версиями iOS/jailbreak. Entitlement no-sandbox расширяет доступ приложения к файловой системе. Используй только на собственном тестовом устройстве. В архиве нет готового IPA — его собирает GitHub Actions.

Попытка создать ветку непосредственно через подключённый GitHub-инструмент завершилась ошибкой 403, поэтому изменения подготовлены архивом, а не записаны в репозиторий.
